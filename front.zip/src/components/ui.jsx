export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
      <div>
        <p className="mb-1 text-xs font-medium text-emerald-700">Team overview</p>
        <h1 className="font-serif text-3xl font-semibold tracking-tight text-stone-900">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-stone-500">{subtitle}</p>}
      </div>
      {children && <div className="flex items-center gap-3">{children}</div>}
    </div>
  );
}


export function Card({ title, action, children, className = '' }) {
  return (
    <section className={`rounded-2xl border border-stone-200 bg-white p-5 ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between">
          {title && <h2 className="font-serif text-lg font-semibold text-stone-900">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

const buttonStyles = {
  primary: 'bg-emerald-900 text-white hover:bg-emerald-800 border border-emerald-900',
  secondary: 'bg-white text-stone-700 hover:bg-stone-50 border border-stone-200',
  soft: 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-transparent',
  danger: 'bg-white text-red-600 hover:bg-red-50 border border-red-200',
};

export function Button({ variant = 'primary', size = 'md', className = '', type = 'button', ...props }) {
  const sizeClass = size === 'sm' ? 'px-3 py-1.5 text-xs' : 'px-4 py-2.5 text-sm';
  return (
    <button
      type={type}
      className={`rounded-lg font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${sizeClass} ${buttonStyles[variant]} ${className}`}
      {...props}
    />
  );
}

export function Alert({ type = 'error', children }) {
  const styles = {
    error: 'border-red-200 bg-red-50 text-red-700',
    success: 'border-emerald-200 bg-emerald-50 text-emerald-800',
    info: 'border-stone-200 bg-stone-50 text-stone-700',
  };
  return (
    <div role={type === 'error' ? 'alert' : 'status'} className={`mb-4 rounded-lg border p-3 text-sm ${styles[type]}`}>
      {children}
    </div>
  );
}


export function Badge({ tone = 'gray', children }) {
  const tones = {
    gray: 'bg-stone-100 text-stone-700 ring-1 ring-inset ring-stone-200',
    blue: 'bg-emerald-900 text-white',
    green: 'bg-emerald-50 text-emerald-800',
    red: 'bg-red-50 text-red-700',
    amber: 'bg-amber-50 text-amber-700',
  };
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>
  );
}

export function EmptyState({ children }) {
  return <p className="py-6 text-center text-sm text-stone-500">{children}</p>;
}


export function Avatar({ src, name = '', size = 'md', className = '' }) {
  const sizes = {
    sm: 'h-8 w-8 text-xs',
    md: 'h-11 w-11 text-sm',
    lg: 'h-20 w-20 text-xl',
  };
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('') || '?';

  if (src) {
    return (
      <img
        src={src}
        alt={name ? `${name}'s photo` : 'Profile photo'}
        className={`${sizes[size]} rounded-full object-cover border border-stone-200 ${className}`}
      />
    );
  }

  return (
    <div
      className={`${sizes[size]} flex items-center justify-center rounded-full bg-emerald-100 font-semibold text-emerald-800 ${className}`}
      aria-label={name ? `${name}'s initials` : 'No photo'}
    >
      {initials}
    </div>
  );
}