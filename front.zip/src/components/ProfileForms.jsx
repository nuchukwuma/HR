import { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { profileSchema, isValidPhotoFile } from '../schemas/profileSchema';
import { api } from '../utils/api';
import { Card, Button, Alert, Avatar } from './ui';

export default function ProfileForm({ userId = 'me' }) {
  const [serverError, setServerError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(true);

  const fileInputRef = useRef(null);
  const [photoUrl, setPhotoUrl] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [photoError, setPhotoError] = useState('');
  const [photoUploading, setPhotoUploading] = useState(false);
  const isNewEmployee = userId === 'new';

  const {
    register,
    handleSubmit,
    reset,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      personalInfo: { firstName: '', lastName: '', phoneNumber: '' },
      address: { street: '', city: '', state: '', country: '' },
      emergencyContact: { name: '', relationship: '', phone: '' },
      employmentType: 'permanent',
      jobTitle: '',
      department: '',
      dateOfBirth: '',
      hireDate: '',
    },
  });

  useEffect(() => {
    if (isNewEmployee) {
      setLoading(false);
      return;
    }
    api(`/profiles/${userId}`)
      .then((res) => {
        const profile = res?.profile || res;
        if (profile) {
          reset({
            ...profile,
            dateOfBirth: profile.dateOfBirth?.slice(0, 10) || '',
            hireDate: profile.hireDate?.slice(0, 10) || '',
          });
          setPhotoUrl(profile.profilePhoto || null);
        }
      })
      .catch((err) => setServerError(err.message || 'Could not load employee profile'))
      .finally(() => setLoading(false));
  }, [userId, reset, isNewEmployee]);


  useEffect(() => {
    return () => {
      if (photoPreview) URL.revokeObjectURL(photoPreview);
    };
  }, [photoPreview]);

  const handlePhotoPick = (e) => {
    const file = e.target.files?.[0];
    e.target.value = ''; 
    if (!file) return;

    setPhotoError('');

    if (!isValidPhotoFile(file)) {
      setPhotoError('Please choose a JPEG, PNG or WebP image under 5MB.');
      return;
    }

    const localPreview = URL.createObjectURL(file);
    setPhotoPreview(localPreview);
    uploadPhoto(file);
  };

  const uploadPhoto = async (file) => {
    setPhotoUploading(true);
    setPhotoError('');
    try {
      const formData = new FormData();
      formData.append('photo', file);


      const res = await fetch(`/api/profiles/${userId}/photo`, {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.message || 'Failed to upload photo.');
      }

      const data = await res.json();
      setPhotoUrl(data.profile?.profilePhoto || data.profilePhoto || null);
      setPhotoPreview(null);
    } catch (err) {
      setPhotoError(err.message || 'Failed to upload photo.');
      setPhotoPreview(null);
    } finally {
      setPhotoUploading(false);
    }
  };

  const onSubmit = async (data) => {
    setServerError('');
    setSuccessMessage('');

    try {
      await api(`/profiles/${userId}`, { method: 'PUT', body: data });
      setSuccessMessage('Profile successfully updated.');
    } catch (err) {
      setServerError(err.message || 'Failed to update profile.');
    }
  };

  if (loading) {
    return (
      <Card>
        <p className="py-8 text-center text-sm text-stone-500">Loading employee profile...</p>
      </Card>
    );
  }

  const displayName = `${getValues('personalInfo.firstName') || ''} ${getValues('personalInfo.lastName') || ''}`.trim();

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {serverError && <Alert type="error">{serverError}</Alert>}
      {successMessage && <Alert type="success">{successMessage}</Alert>}

      {/* Profile Photo */}
      <Card title="Profile Photo">
        {isNewEmployee ? (
          <p className="text-sm text-stone-500">You can add a photo once the profile has been created.</p>
        ) : (
          <div className="flex items-center gap-4">
            <Avatar src={photoPreview || photoUrl} name={displayName} size="lg" />
            <div>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={photoUploading}
              >
                {photoUploading ? 'Uploading...' : photoUrl ? 'Change photo' : 'Upload photo'}
              </Button>
              <p className="mt-1 text-xs text-stone-500">JPEG, PNG or WebP, up to 5MB.</p>
              {photoError && <p className="mt-1 text-xs text-red-600">{photoError}</p>}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handlePhotoPick}
              />
            </div>
          </div>
        )}
      </Card>

      {/* Personal Information */}
      <Card title="Personal Information">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">First Name</label>
            <input
              {...register('personalInfo.firstName')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="Enter first name"
            />
            {errors.personalInfo?.firstName && (
              <p className="mt-1 text-xs text-red-600">{errors.personalInfo.firstName.message}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Last Name</label>
            <input
              {...register('personalInfo.lastName')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="Enter last name"
            />
            {errors.personalInfo?.lastName && (
              <p className="mt-1 text-xs text-red-600">{errors.personalInfo.lastName.message}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Phone Number</label>
            <input
              {...register('personalInfo.phoneNumber')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="+234 ..."
            />
            {errors.personalInfo?.phoneNumber && (
              <p className="mt-1 text-xs text-red-600">{errors.personalInfo.phoneNumber.message}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Date of Birth</label>
            <input
              type="date"
              {...register('dateOfBirth')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            />
            {errors.dateOfBirth && <p className="mt-1 text-xs text-red-600">{errors.dateOfBirth.message}</p>}
          </div>
        </div>
      </Card>

      {/* Employment Details */}
      <Card title="Employment & Position">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Job Title</label>
            <input
              {...register('jobTitle')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="e.g. Software Engineer"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Department</label>
            <input
              {...register('department')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="e.g. Engineering"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Employment Type</label>
            <select
              {...register('employmentType')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="permanent">Permanent</option>
              <option value="temporary">Temporary</option>
              <option value="contract">Contract</option>
              <option value="intern">Intern</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Hire Date</label>
            <input
              type="date"
              {...register('hireDate')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            />
          </div>
        </div>
      </Card>

      {/* Residential Address */}
      <Card title="Residential Address">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Street Address</label>
            <input
              {...register('address.street')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="House number and street name"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">City</label>
            <input
              {...register('address.city')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="City"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">State / Province</label>
            <input
              {...register('address.state')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="State"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Country</label>
            <input
              {...register('address.country')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="Country"
            />
          </div>
        </div>
      </Card>

      {/* Emergency Contact */}
      <Card title="Emergency Contact">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Contact Name</label>
            <input
              {...register('emergencyContact.name')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="Full name"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Relationship</label>
            <input
              {...register('emergencyContact.relationship')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="e.g. Spouse, Sibling"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-900 uppercase mb-1">Phone Number</label>
            <input
              {...register('emergencyContact.phone')}
              className="w-full rounded-lg border border-stone-200 px-3.5 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              placeholder="Phone number"
            />
          </div>
        </div>
      </Card>

      {/* Form Action */}
      <div className="flex justify-end gap-3 pt-2">
        <Button type="submit" variant="primary" disabled={isSubmitting}>
          {isSubmitting ? 'Saving Changes...' : 'Save Profile Information'}
        </Button>
      </div>
    </form>
  );
}