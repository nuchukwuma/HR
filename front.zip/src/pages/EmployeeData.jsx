import ProfileForm from '../components/ProfileForms';
import { PageHeader } from '../components/ui';

const EmployeeData = () => {
  return (
    <div className="space-y-6">
      <PageHeader 
        title="Employee Profile & Records" 
        subtitle="Manage employee personal info, employment details, address, and emergency contacts."
      />
      <ProfileForm />
    </div>
  );
};

export default EmployeeData;